#ifndef SevenSeg_h
#define SevenSeg_h

#include "Arduino.h"

class SevenSeg{

public:
	void numberToDisplay(int num, int disp);

}

#endif